<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_---------  Agribank  Vietcombank  MBBank</name>
   <tag></tag>
   <elementGuidId>9021379f-2bd5-47e7-9521-2f4879eacef6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='id_bank']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#id_bank</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>3351174c-382d-40a5-947e-ef4784eed4db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>bank</value>
      <webElementGuid>31a691dd-f29c-4381-b660-3d951051c444</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>id_bank</value>
      <webElementGuid>b3037152-59d0-4982-998d-156d6e5b0e2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  ---------

  Agribank

  Vietcombank

  MBBank

</value>
      <webElementGuid>c4c69303-d453-4e7f-849d-ee03bb83a649</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;id_bank&quot;)</value>
      <webElementGuid>16ec6171-1d5a-4e35-acd6-fbfdfb87c703</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='id_bank']</value>
      <webElementGuid>d6b14901-46f4-4cc2-97f0-567f32495020</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='bank_account']/div/select</value>
      <webElementGuid>7ed1400f-2435-47b6-8e2b-7e718ef80a3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bank:'])[1]/following::select[1]</value>
      <webElementGuid>e95a4903-8af8-4a40-8127-14efaed86086</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Purchase'])[2]/following::select[1]</value>
      <webElementGuid>26df2f51-7177-450e-879f-d39e696c01ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account:'])[1]/preceding::select[1]</value>
      <webElementGuid>96253089-c10b-4923-a5af-1d7b35bc56b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Value:'])[2]/preceding::select[1]</value>
      <webElementGuid>8088f780-beff-4859-970e-6d674f750596</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/form/div/select</value>
      <webElementGuid>3fde97ba-80f5-49d4-8edf-6aa719515dad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'bank' and @id = 'id_bank' and (text() = '
  ---------

  Agribank

  Vietcombank

  MBBank

' or . = '
  ---------

  Agribank

  Vietcombank

  MBBank

')]</value>
      <webElementGuid>b995e84b-4626-4069-b2ed-aa1d8dfcad01</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
