<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Sign In                    Login and s_6c4fbd</name>
   <tag></tag>
   <elementGuidId>1c7897fa-3b39-4ae8-8b14-9a6bd36e481e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='signup-form']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#signup-form</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>085299fc-13c0-4533-95a1-1105969fbe4d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>POST</value>
      <webElementGuid>f54c5d2b-e3a8-4568-bf97-1f4b9de995bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>signup-form</value>
      <webElementGuid>3cf693cc-d867-46cd-a937-9f610ab9737d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>signup-form</value>
      <webElementGuid>aa04c2d4-fa83-4f05-ab33-5f992b492899</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    
                    Sign In
                    Login and start the adventure
                    
                              
                    
                    
                    
                              
                    
                    
                    
                        
                        Sign up
                    
                    
    
                </value>
      <webElementGuid>fd5bd829-0c98-4697-b8a5-9a314647ae5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;signup-form&quot;)</value>
      <webElementGuid>95400542-c854-46e0-9d75-2a90b51d11b2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@id='signup-form']</value>
      <webElementGuid>953473fa-50c7-4b7a-89bc-207045e9f2eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>d81c527b-4671-4d55-8e3c-4271ff400748</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[@id = 'signup-form' and (text() = '
                    
                    Sign In
                    Login and start the adventure
                    
                              
                    
                    
                    
                              
                    
                    
                    
                        
                        Sign up
                    
                    
    
                ' or . = '
                    
                    Sign In
                    Login and start the adventure
                    
                              
                    
                    
                    
                              
                    
                    
                    
                        
                        Sign up
                    
                    
    
                ')]</value>
      <webElementGuid>df4f8010-b4ab-489f-a363-be4cfb8c1242</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
