<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>testSuit2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c54f5edf-4ee8-43aa-946e-70f06e247bb4</testSuiteGuid>
   <testCaseLink>
      <guid>9b3fd379-309b-4db6-b082-dd09c117dd5f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/test_payment_2</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>04ea8ebf-ae60-44a2-9a2e-28153d9fef29</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/data2</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>04ea8ebf-ae60-44a2-9a2e-28153d9fef29</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>value</value>
         <variableId>d6d2a133-77e0-49cc-8ac1-a64f942d1d2c</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
