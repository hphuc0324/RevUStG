<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>suite2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>7a910a1c-2aea-4482-8be8-ba983b27e404</testSuiteGuid>
   <testCaseLink>
      <guid>a71d6474-d33c-4979-86d4-1acf42ecd6c6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/invalid_search</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>62038c96-f981-42f8-8b51-7e06be8095f3</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>62038c96-f981-42f8-8b51-7e06be8095f3</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Invalid Product</value>
         <variableId>43256505-9d9a-49bb-968e-187b445f494a</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
