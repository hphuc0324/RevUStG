<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>suite1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>261c5e81-0766-4168-b1f1-2eccd295ccbe</testSuiteGuid>
   <testCaseLink>
      <guid>73b5e40f-949c-42e5-a1d2-f93ebc5f2e5e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/valid_search</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>cb804804-6127-49e9-aa88-26ec63033004</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>cb804804-6127-49e9-aa88-26ec63033004</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Valid product</value>
         <variableId>3800b6ff-51fe-40d5-8d5d-50d087f2bb47</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
