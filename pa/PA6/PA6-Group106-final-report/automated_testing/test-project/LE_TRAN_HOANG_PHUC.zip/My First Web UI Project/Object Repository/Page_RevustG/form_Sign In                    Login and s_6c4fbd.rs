<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Sign In                    Login and s_6c4fbd</name>
   <tag></tag>
   <elementGuidId>2bd989fc-b591-45fc-88ac-9ac5db97999a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='signup-form']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#signup-form</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>1069b35a-fa73-481b-8634-d5380a4b20f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>POST</value>
      <webElementGuid>8d675ec5-a935-4775-bf39-812783c0cbe6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>signup-form</value>
      <webElementGuid>f9ebe0cf-54bd-4a0b-a752-c8f0dfa10fef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>signup-form</value>
      <webElementGuid>469fdd0c-aecb-4986-9dac-edaee5d2d315</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    
                    Sign In
                    Login and start the adventure
                    
                              
                    
                    
                    
                              
                    
                    
                    
                        
                        Sign up
                    
                    
    
                </value>
      <webElementGuid>623098a7-7884-44a6-9b14-71a2bd0324a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;signup-form&quot;)</value>
      <webElementGuid>f06ddcc1-1792-4fb6-989a-130b6846d46a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@id='signup-form']</value>
      <webElementGuid>b2971fd8-ebd6-42d5-b90a-473fdaafada0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>8aacf14f-3992-40ad-b520-22a66d38fe49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[@id = 'signup-form' and (text() = '
                    
                    Sign In
                    Login and start the adventure
                    
                              
                    
                    
                    
                              
                    
                    
                    
                        
                        Sign up
                    
                    
    
                ' or . = '
                    
                    Sign In
                    Login and start the adventure
                    
                              
                    
                    
                    
                              
                    
                    
                    
                        
                        Sign up
                    
                    
    
                ')]</value>
      <webElementGuid>57a5d202-09c6-4cc0-8e39-6361f3830251</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
